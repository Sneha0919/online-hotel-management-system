package com.cyan.hotel.enumeration;

public enum LoyatyLevel {
    Copper,
    Silver,
    Gold,
    Platinum
}
