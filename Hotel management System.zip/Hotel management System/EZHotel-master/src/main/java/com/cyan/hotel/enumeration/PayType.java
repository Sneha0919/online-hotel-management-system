package com.cyan.hotel.enumeration;

public enum PayType {
    Cash,
    Cheque,
    CreditCard,
    DebitCard
}
