package com.cyan.hotel.enumeration;

public enum RoomStyle {
    EXECUTIVE,
    SINGLE,
    DOUBLE,
    JUNIORSUITE
}
